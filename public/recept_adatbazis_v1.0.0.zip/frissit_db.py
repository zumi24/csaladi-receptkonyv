import sqlite3

conn = sqlite3.connect("receptek.db")
cursor = conn.cursor()

# 1. Kategóriák tábla létrehozása
cursor.execute(
    """
CREATE TABLE IF NOT EXISTS kategoria (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nev TEXT UNIQUE
)
"""
)

# Alapértelmezett kategóriák feltöltése (ha még nincsenek ott)
alap_kategoriak = [("Levesek",), ("Készételek",), ("Desszertek",)]
cursor.executemany(
    "INSERT OR IGNORE INTO kategoria (nev) VALUES (?)", alap_kategoriak
)

# 2. A receptek tábla újragondolása (képekkel és kategória kapcsolattal)
# Eldobjuk a régit, hogy tiszta lappal induljunk az új struktúrához
cursor.execute("DROP TABLE IF EXISTS receptek")

cursor.execute(
    """
CREATE TABLE IF NOT EXISTS receptek (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nev TEXT,
    kategoria_id INTEGER,
    hozzavalok TEXT,
    leiras TEXT,
    kep_utvonal TEXT,
    FOREIGN KEY (kategoria_id) REFERENCES kategoria (id)
)
"""
)

# Mintareceptek beszúrása az új struktúra szerint (ID-k: 1-Levesek, 2-Készételek, 3-Desszertek)
mintareceptek = [
    (
        "Hagyományos Palacsinta",
        3,
        "20 dkg liszt, 2 db tojás, 3 dl tej",
        "Kikeverjük és kisütjük.",
        "default.jpg",
    ),
    (
        "Gulyásleves",
        1,
        "50 dkg marhahús, hagyma, répa",
        "Pörkölt alapot készítünk, vízzel felöntjük, zöldségekkel főzzük.",
        "default.jpg",
    ),
    (
        "Rántott Sajt",
        2,
        "40 dkg sajt, tojás, morzsa",
        "Duplán panírozzuk, kisütjük.",
        "default.jpg",
    ),
]

cursor.executemany(
    """
INSERT INTO receptek (nev, kategoria_id, hozzavalok, leiras, kep_utvonal)
VALUES (?, ?, ?, ?, ?)
""",
    mintareceptek,
)

conn.commit()
conn.close()
print("🎉 Az adatbázis sikeresen átalakítva a kategória-gombokhoz és képekhez!")
