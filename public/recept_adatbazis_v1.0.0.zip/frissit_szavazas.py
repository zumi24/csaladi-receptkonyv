import sqlite3

conn = sqlite3.connect("receptek.db")
cursor = conn.cursor()

# Új tábla a családi visszajelzéseknek
cursor.execute(
    """
CREATE TABLE IF NOT EXISTS szavazatok (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recept_id INTEGER,
    nev TEXT,
    ertekeles TEXT, -- 'REMETEK' (Ízlik) vagy 'NEM_IZLIK'
    FOREIGN KEY (recept_id) REFERENCES receptek (id),
    UNIQUE(recept_id, nev) -- Egy ember egy receptre csak egyszer szavazhat, így tiszta!
)
"""
)

conn.commit()
conn.close()
print("🎉 A szavazás tábla sikeresen hozzáadva!")
