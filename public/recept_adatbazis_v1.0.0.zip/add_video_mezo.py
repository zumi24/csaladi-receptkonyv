import sqlite3

conn = sqlite3.connect("receptek.db")
cursor = conn.cursor()

try:
    cursor.execute("ALTER TABLE receptek ADD COLUMN video_url TEXT")
    print("🎉 A YouTube link oszlop sikeresen hozzáadva!")
except sqlite3.OperationalError:
    print("ℹ️ Az oszlop már létezik az adatbázisban.")

conn.commit()
conn.close()
