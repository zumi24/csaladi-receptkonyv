import sqlite3

conn = sqlite3.connect("receptek.db")
cursor = conn.cursor()

# Családtagok tábla
cursor.execute(
    """
CREATE TABLE IF NOT EXISTS csaladtag (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nev TEXT UNIQUE
)
"""
)

# TODO: Írd át a neveket a saját családotok tagjaira!
csaladtagok = [("Anya",), ("Apa",), ("Krisi",), ("Rolcsi",), ("Mark",), ("Brigi",)]

cursor.executemany(
    "INSERT OR IGNORE INTO csaladtag (nev) VALUES (?)", csaladtagok
)
conn.commit()
conn.close()
print("🎉 A családtagok sikeresen hozzáadva az adatbázishoz!")

