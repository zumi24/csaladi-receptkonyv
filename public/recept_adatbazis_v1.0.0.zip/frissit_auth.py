import sqlite3
from werkzeug.security import generate_password_hash

conn = sqlite3.connect("receptek.db")
cursor = conn.cursor()

# 1. Felhasználó tábla létrehozása (JAVÍTVA: NOT NULL használata NOT EXISTS helyett)
cursor.execute(
    """
CREATE TABLE IF NOT EXISTS felhasznalo (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    felhasznalonev TEXT UNIQUE NOT NULL,
    jelszo_hash TEXT NOT NULL,
    szerep TEXT DEFAULT 'user' -- 'admin' vagy 'user'
)
"""
)

# Alapértelmezett Admin fiók létrehozása (ha még nem létezik)
admin_email = "admin@csalad.hu"
admin_nev = "admin"
admin_jelszo_hash = generate_password_hash("admin123")

cursor.execute(
    """
INSERT OR IGNORE INTO felhasznalo (email, felhasznalonev, jelszo_hash, szerep)
VALUES (?, ?, ?, 'admin')
""",
    (admin_email, admin_nev, admin_jelszo_hash),
)

# 2. A receptek tábla kiegészítése a tulajdonos azonosítójával (felhasznalo_id)
try:
    cursor.execute("ALTER TABLE receptek ADD COLUMN felhasznalo_id INTEGER")
    print("🎉 A felhasznalo_id oszlop sikeresen hozzáadva a receptekhez!")
except sqlite3.OperationalError:
    print("ℹ️ A felhasznalo_id oszlop már létezik.")

# A meglévő mintarecepteket hozzárendeljük az adminhoz (id: 1), hogy ne maradjanak gazdátlanul
cursor.execute("UPDATE receptek SET felhasznalo_id = 1 WHERE felhasznalo_id IS NULL")

conn.commit()
conn.close()
print("🎉 Az adatbázis felkészítve a regisztrációra és jogosultságokra!")
