import sqlite3

# 1. Kapcsolódás az adatbázishoz
conn = sqlite3.connect("receptek.db")
cursor = conn.cursor()

# 2. A receptek tábla létrehozása (JAVÍTOTT SOR: nev TEXT)
cursor.execute(
    """
CREATE TABLE IF NOT EXISTS receptek (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nev TEXT,
    kategoria TEXT,
    hozzavalok TEXT,
    leiras TEXT
)
"""
)

# 3. Mintareceptek listája a teszteléshez
mintareceptek = [
    (
        "Hagyományos Palacsinta",
        "Desszert",
        "20 dkg liszt, 2 db tojás, 3 dl tej, 2 dl szódavíz, csipet só, 1 ek olaj",
        "A hozzávalókat csomómentesre keverjük, 20 percet pihentetjük, majd forró, kiolajozott serpenyőben kisütjük.",
    ),
    (
        "Gulyásleves",
        "Leves",
        "50 dkg marhahús, 2 fej hagyma, 3 db sárgarépa, 2 db burgonya, pirospaprika, só, bors, kömény",
        "A hagymát üvegesre pirítjuk, rádobjuk a húst és a fűszereket. Felöntjük vízzel, majd amikor a hús félpuha, hozzáadjuk a zöldségeket és készre főzzük.",
    ),
    (
        "Rántott Sajt",
        "Főétel",
        "40 dkg trappista sajt, 2 db tojás, liszt, zsemlemorzsa, olaj a sütéshez",
        "A sajtot ujjnyi vastagra vágjuk. Duplán panírozzuk (liszt-tojás-morzsa-tojás-morzsa), hogy ne folyjon ki, majd forró olajban hirtelen kisütjük.",
    ),
]

# 4. A mintareceptek beszúrása az adatbázisba
cursor.executemany(
    """
INSERT INTO receptek (nev, kategoria, hozzavalok, leiras)
VALUES (?, ?, ?, ?)
""",
    mintareceptek,
)

# 5. Változtatások mentése és a kapcsolat lezárása
conn.commit()
conn.close()

print("🎉 Siker! Az adatbázis és a mintareceptek elkészültek!")
