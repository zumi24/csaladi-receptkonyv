import sqlite3

conn = sqlite3.connect("receptek.db")
cursor = conn.cursor()

# Új oszlopok hozzáadása a receptek táblához
try:
    cursor.execute("ALTER TABLE receptek ADD COLUMN megjegyzes TEXT")
    cursor.execute("ALTER TABLE receptek ADD COLUMN adag INTEGER")
    cursor.execute("ALTER TABLE receptek ADD COLUMN ido TEXT")
    print("🎉 Az új oszlopok (Megjegyzés, Adag, Idő) sikeresen hozzáadva!")
except sqlite3.OperationalError:
    print("ℹ️ Az oszlopok már léteznek az adatbázisban.")

conn.commit()
conn.close()
